document.addEventListener("DOMContentLoaded", function () {
  var fileInput = document.querySelector("#P1_PDF_FILE");
  if (!fileInput) {
    console.error("❌ File input not found: #P1_PDF_FILE");
    return;
  }

  fileInput.addEventListener("change", function (e) {
    var file = e.target.files[0];
    if (!file) {
      console.warn("No PDF selected");
      return;
    }

    var reader = new FileReader();
    reader.onload = function () {
      var typedarray = new Uint8Array(this.result);

      pdfjsLib.getDocument(typedarray).promise.then(function (pdf) {
        console.log("✅ PDF loaded successfully. Total pages:", pdf.numPages);

        var fullText = "";
        var totalPages = pdf.numPages;
        var currentPage = 1;

        function readPage() {
          pdf.getPage(currentPage).then(function (page) {
            page.getTextContent().then(function (textContent) {
              var textItems = textContent.items;
              var finalString = "";
              for (var i = 0; i < textItems.length; i++) {
                finalString += textItems[i].str + " ";
              }
              fullText += finalString + "\n";

              if (currentPage < totalPages) {
                currentPage++;
                readPage();
              } else {
                console.log("✅ PDF Text Extraction Complete");
                console.log(fullText);

                // ✅ Example of auto-fill logic
                var nameMatch = fullText.match(/name\s*[:\-]?\s*([A-Za-z\s]+)/i);
                var ageMatch = fullText.match(/age\s*[:\-]?\s*(\d{1,2})/i);
                var roleMatch = fullText.match(/role\s*[:\-]?\s*([A-Za-z\s]+)/i);

                if (nameMatch) apex.item("P1_NAME").setValue(nameMatch[1].trim());
                if (ageMatch) apex.item("P1_AGE").setValue(ageMatch[1].trim());
                if (roleMatch) apex.item("P1_ROLE").setValue(roleMatch[1].trim());
              }
            });
          });
        }

        readPage();
      }).catch(function (error) {
        console.error("❌ Error loading PDF:", error);
      });
    };

    reader.readAsArrayBuffer(file);
  });
});
